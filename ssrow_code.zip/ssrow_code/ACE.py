import time

import numpy as np
from matplotlib import pyplot as plt
from sklearn.metrics import auc, roc_curve

from airport.module import open_file
from utils import ts_generation


def hyperCorr(M):
    p, N = M.shape
    R = np.dot(M, M.T) / N
    regularization_lambda = 1e-6
    R = R + regularization_lambda * np.identity(p)
    return R

def hyperConvert2d(M):
    if M.ndim > 3 or M.ndim < 2:
        raise ValueError("Input image must be m x n x p or m x n")

    if M.ndim == 2:
        numBands = 1
        h, w = M.shape
    else:
        h, w, numBands = M.shape

    M = np.reshape(M, (w * h, numBands)).T
    return M


def hyperConvert3d(M, h, w, numBands):
    if M.ndim != 2:
        raise ValueError("Input image must be p x N.")

    numBands, N = M.shape

    if N == 1:
        M = np.reshape(M, (h, w))
    else:
        M = np.reshape(M.T, (h, w, numBands))

    return M


def hyper_normalize(M):
    min_val = M.min()
    max_val = M.max()

    normalized_M = M - min_val
    if max_val == min_val:
        normalized_data = np.zeros(M.shape)
    else:
        normalized_M = normalized_M / (max_val - min_val)

    return normalized_M


def hyperCov(M):
    """
    Computes the covariance matrix.

    Args:
    - M (numpy.ndarray): 2D matrix

    Returns:
    - C (numpy.ndarray): Sample covariance matrix
    """
    p, N = M.shape
    # Remove mean from data
    u = np.mean(M, axis=1).reshape(-1, 1)
    M = M - u

    C = np.dot(M, M.T) / (N - 1)
    # regularization_lambda = 1e-2
    # C = C + regularization_lambda * np.identity(p)
    return C


def hyperAce(M, S):
    """
    Performs the adaptive cosine/coherent estimator algorithm for target detection.

    Args:
    - M (numpy.ndarray): 2D matrix of HSI data (p x N)
    - S (numpy.ndarray): 2D matrix of target endmembers (p x q)

    Returns:
    - results (numpy.ndarray): vector of detector output (N x 1)
    """
    p, N = M.shape
    # Remove mean from data
    u = np.mean(M, axis=1).reshape(-1, 1)
    M = M - u
    S = S - u

    # R_hat = hyperCov(M)
    R_hat = hyperCorr(M)
    G = np.linalg.inv(R_hat)

    results = np.zeros((1, N))
    # From Broadwater's paper
    # tmp = G*S*inv(S.'*G*S)*S.'*G;
    tmp = np.dot(np.dot(S.T, G), S)
    for k in range(N):
        x = M[:, k].reshape(-1, 1)
        # From Broadwater's paper
        # results(k) = (x.'*tmp*x) / (x.'*G*x);
        results[0, k] = np.dot(np.dot(S.T, G), x) ** 2 / (np.dot(tmp, np.dot(x.T, np.dot(G, x))))
    return results


def hyperCem(M, target):
    # Check dimensions
    if M.ndim != 2:
        raise ValueError("Input image must be p x N.")

    p, N = M.shape  # 205  10000
    if not np.array_equal(target.shape, (p, 1)):
        raise ValueError("Input target must be p x 1.")

    # CEM uses the correlation matrix, NOT the covariance matrix.

    R_hat = hyperCorr(M)  # 205*205
    # Equation 6: w = inv(target' * inv(R) * target) * inv(R) * target
    invRtarget = np.dot(np.linalg.pinv(R_hat), target)
    weights = np.dot(invRtarget, np.linalg.pinv(np.dot(target.T, invRtarget)))
    results = np.dot(weights.T, M)
    return results


dataset = 'E:/exp/dataset/abu-urban-1.mat'
img_dataset = open_file(dataset, 'data')
ground_truth = open_file(dataset, 'map')
d_dataset = ts_generation(img_dataset, ground_truth, type=0)
d_dataset = hyper_normalize(d_dataset)
img_norm = hyper_normalize(img_dataset)
M_2d = hyperConvert2d(img_norm)
h, w, p = img_dataset.shape[0], img_dataset.shape[1], img_dataset.shape[2]

# ============================
start_time = time.time()
r1 = hyperCem(M_2d, d_dataset)
out_1 = hyperConvert3d(r1, h, w, 1)
end_time = time.time()
duration = end_time - start_time
print(f"程序运行时长1：{duration}秒")

start_time = time.time()
r2 = hyperAce(M_2d, d_dataset)
out_2 = hyperConvert3d(r2, h, w, 1)
end_time = time.time()
duration = end_time - start_time
print(f"程序运行时长2：{duration}秒")

plt.figure(1)
plt.subplot(2, 2, 1)
plt.imshow(img_norm[:, :, 29], cmap='gray'), plt.axis('off'), plt.title('orinal_img')
plt.subplot(2, 2, 2)
plt.imshow(ground_truth, cmap='gray'), plt.axis('off')
plt.subplot(2, 2, 3), plt.imshow(np.abs(out_1)), plt.title('CEM Detector'), plt.axis('off')
plt.subplot(2, 2, 4), plt.imshow(np.abs(out_2)), plt.title('ACE Detector'), plt.axis('off')
plt.tight_layout()
plt.show()

fpr_out_1, tpr_out_1, thresholds_out_1 = roc_curve(ground_truth.flatten(), out_1.flatten())
roc_auc_out_1 = auc(fpr_out_1, tpr_out_1)

fpr_out_2, tpr_out_2, thresholds_out_2 = roc_curve(ground_truth.flatten(), out_2.flatten())
roc_auc_out_2 = auc(fpr_out_2, tpr_out_2)

plt.figure(figsize=(8, 6))
plt.plot(fpr_out_1, tpr_out_1, color='red', lw=2, label='CEM (area = %0.7f)' % roc_auc_out_1)
plt.plot(fpr_out_2, tpr_out_2, color='green', lw=2, label='ACE (area = %0.7f)' % roc_auc_out_2)
plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver Operating Characteristic')
plt.legend(loc="lower right")
plt.show()
