import math
import time

import numpy as np
import torch
from matplotlib import pyplot as plt
from scipy.io import savemat
from sklearn.decomposition import PCA
from torch import nn, optim
from torch.utils.data import TensorDataset, DataLoader
import torch.nn.functional as F

from module import open_file, hyper_normalize, hyperCem, hyperConvert3d, hyperConvert2d
from utils import get_target_information, ts_generation


class VAE(nn.Module):
    def __init__(self, input_size, latent_size, hidden_size, lambda_value=0.1):
        super(VAE, self).__init__()
        self.lambda_value = lambda_value
        self.encoder = nn.Sequential(
            nn.Linear(input_size, hidden_size * 2),
            nn.ReLU(),
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 2 * latent_size)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size * 2),
            nn.ReLU(),
            nn.Linear(hidden_size * 2, input_size)
        )

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        mu = mu / torch.sqrt(1 + self.lambda_value * torch.sum(torch.exp(logvar) ** 2))
        return mu + eps * std

    def forward(self, x):
        encoded = self.encoder(x)
        mu, logvar = encoded.chunk(2, dim=-1)
        z = self.reparameterize(mu, logvar)
        reconstructed = self.decoder(z)
        return reconstructed, mu, logvar


class Generator(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.Tanh()
        )

    def forward(self, x):
        return self.model(x)


class Discriminator(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)


def apply_pca(image_data, n_components):
    # 将图像数据转换为二维数组，每一行表示一个样本
    num_samples = image_data.shape[0] * image_data.shape[1]
    flattened_data = image_data.reshape(num_samples, -1)

    # 创建PCA对象并拟合数据
    pca = PCA(n_components=n_components)
    pca.fit(flattened_data)

    # 将数据投影到新的低维空间
    reduced_data = pca.transform(flattened_data)

    # 将降维后的数据转换回原始形状
    reconstructed_data = pca.inverse_transform(reduced_data)
    reconstructed_data = reconstructed_data.reshape(image_data.shape)

    return reduced_data, reconstructed_data


def psnr(data_input, reconstruct):
    data_input = (data_input - data_input.min()) / (data_input.max() - data_input.min())
    reconstruct = (reconstruct - reconstruct.min()) / (reconstruct.max() - reconstruct.min())

    data_input_cpu = data_input.detach().cpu().numpy()  # 将data_input转移到CPU并转换为numpy数组
    reconstruct_cpu = reconstruct.detach().cpu().numpy()  # 将reconstruct转移到CPU并转换为numpy数组

    target_data = np.array(data_input_cpu)
    ref_data = np.array(reconstruct_cpu)
    diff = ref_data - target_data
    diff = diff.flatten('C')
    rmse = math.sqrt(np.mean(diff ** 2.))

    return 20 * np.log10(1.0 / rmse)


def get_opcs(M_2d, num_band):
    mean = np.mean(M_2d, axis=0)
    centered_img = M_2d - mean
    cov_matrix = np.cov(centered_img)
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvalues = eigenvalues[sorted_indices]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]
    q = 1
    U = sorted_eigenvectors[:, :q]  # (224, 224)

    unit_matrix = np.eye(num_band, dtype=float)
    # ones_matrix = np.ones(num_band)
    invs = np.linalg.inv(np.dot(U.T, U))
    # P = ones_matrix - np.dot(np.dot(U, invs), U.T)
    P = unit_matrix - np.dot(np.dot(U, invs), U.T)

    return P, U


# =================
start_time = time.time()
dataset = 'E:/ssrow_code/dataset/abu-airport-4.mat'
img_dataset = open_file(dataset, 'data')
ground_truth = open_file(dataset, 'map')
d_dataset = ts_generation(img_dataset, ground_truth, type=0)
# d_dataset = img_dataset[54, 29, :].reshape(-1, 1)
d_dataset = hyper_normalize(d_dataset)

img_norm = hyper_normalize(img_dataset)  # (100, 100, 191)
M_2d = hyperConvert2d(img_norm)
img_2d = torch.tensor(M_2d.T).float()  #
print('img', img_2d.shape)

# 模型参数
input_size = img_2d.shape[1]  # 191
latent_size = 256
hidden_size = 512
batch_size = 256
epochs = 100
learning_rate = 0.001

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
vae = VAE(input_size, latent_size, hidden_size).to(device)
discriminator = Discriminator(input_size, hidden_size).to(device)
vae_optimizer = optim.Adam(vae.parameters(), lr=learning_rate)
dis_optimizer = optim.Adam(discriminator.parameters(), lr=learning_rate)

criterion = nn.MSELoss()
torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=1)

# data_segundo = 'airport_4/airport_data.mat'
# target = torch.tensor(open_file(data_segundo, 'target').T)  # torch.Size([224, 2176])
# background = torch.tensor(open_file(data_segundo, 'background').T).float()  # torch.Size([224, 72824])

img_dataset_1 = TensorDataset(img_2d)
dataloader = DataLoader(img_dataset_1, batch_size=batch_size, shuffle=True)
# vae_scheduler = optim.lr_scheduler.ReduceLROnPlateau(vae_optimizer, mode='min', factor=0.5, patience=5, verbose=True)
# dis_scheduler = optim.lr_scheduler.ReduceLROnPlateau(dis_optimizer, mode='min', factor=0.5, patience=5, verbose=True)

print('--------------训练开始-----------------')
for epoch in range(epochs):
    vae.train()
    total_vae_loss = 0
    total_discriminator_loss = 0
    reconstructed_spectrum = []
    original_results = []
    reconstructed_results = []

    best_psnr = float('-inf')
    best_model_state = None
    for data in dataloader:
        data = data[0].to(device)
        vae_optimizer.zero_grad()
        discriminator_output_original = discriminator(data.to(device))

        reconstructed, mu, logvar = vae(data)
        reconstruct_train_psnr = psnr(data, reconstructed)

        discriminator_real = discriminator(data)
        discriminator_fake = discriminator(reconstructed)

        discriminator_output_reconstructed = discriminator(reconstructed.to(device))

        recon_loss = F.mse_loss(reconstructed, data, reduction='sum')
        kl_divergence = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        vae_loss = recon_loss + kl_divergence

        discriminator_loss = criterion(discriminator_real, torch.ones_like(discriminator_real).to(device)) + \
                             criterion(discriminator_fake, torch.zeros_like(discriminator_fake).to(device))

        total_loss = vae_loss + discriminator_loss
        vae_loss.backward()
        vae_optimizer.step()

        total_vae_loss += vae_loss.item()
        total_discriminator_loss += discriminator_loss.item()

        reconstructed_results.append(discriminator_output_reconstructed.detach().cpu().numpy())
        original_results.append(discriminator_output_original.detach().cpu().numpy())
        reconstructed_spectrum.append(reconstructed.detach().cpu().numpy())

    avg_vae_loss = total_vae_loss / len(dataloader.dataset)
    avg_dis_loss = total_discriminator_loss / len(dataloader.dataset)

    print(f'Epoch [{epoch + 1}/{epochs}], VAE Loss: {avg_vae_loss}, '
          f'Discriminator Loss: {avg_dis_loss}, psnr:{reconstruct_train_psnr}')

    if reconstruct_train_psnr > best_psnr:
        best_psnr = reconstruct_train_psnr
        best_model_state = vae.state_dict()

# 生成重构
reconstruct_spectral = np.concatenate(reconstructed_spectrum, axis=0)
original_results = np.concatenate(original_results)
reconstruct_results = np.concatenate(reconstructed_results)

print('Training finished.')

# ==================
print('recon', reconstruct_spectral.shape, original_results.shape, reconstruct_results.shape)
savemat('E:/ssrow_code/abu-airport-4/reconstructed_spectral.mat', {'reconstructed_spectral': reconstruct_spectral})
savemat('E:/ssrow_code/abu-airport-4/spectral_VAE_DIS.mat', {'original_results': original_results, 'reconstructed_results': reconstruct_results})
# savemat('airport_4/reconstructed_background.mat', {'reconstructed_background': reconstructed})
print('保存重构后的光谱数据')


result_recon = hyperCem(reconstruct_spectral.T, d_dataset, reconstruct_spectral.T)
out_recon = hyperConvert3d(result_recon, img_norm.shape[0], img_norm.shape[1], 1)
plt.figure()
plt.imshow(out_recon), plt.axis('off'), plt.title('reconstruct spectral')
plt.show()
end_time = time.time()
duration = end_time - start_time
print(f"程序运行时长：{duration}秒")