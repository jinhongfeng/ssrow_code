import numpy as np
from matplotlib import pyplot as plt
from scipy.io import savemat

from module import open_file, hyperCem, hyperConvert3d, hyper_normalize, hyperConvert2d
from utils import ts_generation

dataset_1 = 'abu-airport-4'
dataset = f'E:/ssrow_code/dataset/{dataset_1}.mat'
img_dataset = open_file(dataset, 'data')  # (250,300,224)
ground_truth = open_file(dataset, 'map')  # (250, 300)
d_dataset = ts_generation(img_dataset, ground_truth, type=0)
# d_dataset = hyper_normalize(d_dataset)

img_norm = hyper_normalize(img_dataset)

M_2d = hyperConvert2d(img_norm)

print(M_2d.shape)
# ================
threshold = 1e-8  # 1.2e-2
train_rate = 0.75

result_coarse = hyperCem(M_2d, d_dataset, M_2d)  # (1, 75000)
out_coarse = hyperConvert3d(result_coarse, img_norm.shape[0], img_norm.shape[1], 1)  # (250, 300, 1)
print(out_coarse)
# 二值化 binarization
result_binary = result_coarse.copy()

a, b = np.where(result_binary > threshold)
result_binary[a, b] = 1
c, d = np.where(result_binary < threshold)
result_binary[c, d] = 0  # (1, 10000)

h_1, w_1 = ground_truth.shape
result_binary = result_binary.reshape(h_1, w_1)
h, w, p = img_dataset.shape[0], img_dataset.shape[1], img_dataset.shape[2]
# 得到训练数据
b_Max = len(c)
t_Max = len(a)
background = np.zeros((b_Max, p))
target = np.zeros((t_Max, p))
for i in range(b_Max):
    background[i] = M_2d[c[i], d[i]]  # (73105, 224)
for i in range(t_Max):
    target[i] = M_2d[a[i], b[i]]  # (1895, 224)

# 建立数据集
b_rowrank = np.random.permutation(b_Max)
background = background[b_rowrank]
b_m = int(np.ceil(train_rate * b_Max))
train_data_background = background[:b_m]
val_data_background = background[b_m:]

t_rowrank = np.random.permutation(t_Max)
target = target[t_rowrank]
t_m = int(np.ceil(train_rate * t_Max))
train_data_target = target[:t_m]
val_data_target = target[t_m:]
savemat('./train_data.mat', {'train_data': train_data_background})
savemat('./val_data.mat', {'val_data': val_data_background})
print('target', target.shape, background.shape)
# ====================

plt.figure(1)
plt.subplot(2, 2, 1), plt.imshow(img_norm[:, :, 29], cmap='gray'), plt.axis('off')
plt.title('Original  Image')
plt.subplot(2, 2, 2), plt.imshow(ground_truth), plt.title('ground truth'), plt.axis('off')
plt.subplot(2, 2, 3), plt.imshow(out_coarse), plt.title('coarse_detection'), plt.axis('off')

plt.subplot(2, 2, 4)
plt.imshow(np.abs(out_coarse) > threshold), plt.title('CEM label'), plt.axis('off')
plt.tight_layout()
# plt.savefig('C:/Users/24749/Desktop/trymeidea/result_images' + '/main_1.png')
plt.show()

savemat(f'./{dataset_1}_data.mat',
        {'background': background, 'target': target})
print('保存成功！')
savemat(f'./result_{dataset_1}.mat', {'result_coarse': result_coarse})
