import math
import os
import time

import cv2
import imageio
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from scipy import interpolate
from scipy.io import savemat
from torch import optim
from torch.utils.data import DataLoader, TensorDataset
from module import open_file, hyper_normalize, hyperConvert2d, hyperCem, hyperConvert3d
import torch.nn.functional as F
from utils import  ts_generation


class SelfAttention(nn.Module):
    def __init__(self, embed_dim):
        super(SelfAttention, self).__init__()
        self.query = nn.Linear(embed_dim, embed_dim)
        self.key = nn.Linear(embed_dim, embed_dim)
        self.value = nn.Linear(embed_dim, embed_dim)

    def forward(self, x):
        q = self.query(x)  # (191, 2048)
        k = self.key(x)
        v = self.value(x)
        # print('q', q.shape, k.shape, v.shape)
        k_transpose = k.transpose(0, 1)  # 转置 k
        attn_weights = torch.matmul(q, k_transpose)
        attn_weights = F.softmax(attn_weights, dim=-1)
        attended_values = torch.matmul(attn_weights, v)
        return attended_values


class VAE(nn.Module):
    def __init__(self, input_size, latent_size, hidden_size, output_size, lambda_value=0.1):
        super(VAE, self).__init__()
        self.lambda_value = lambda_value
        self.encoder = nn.Sequential(
            nn.Linear(input_size, hidden_size * 4),
            nn.ReLU(),
            nn.Linear(hidden_size * 4, hidden_size * 2),
            nn.ReLU(),
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 2 * latent_size)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size * 2),
            nn.ReLU(),
            nn.Linear(hidden_size * 2, hidden_size * 4),
            nn.ReLU(),
            SelfAttention(hidden_size * 4),
            nn.Linear(hidden_size * 4, output_size)
        )

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        mu = mu / torch.sqrt(1 + self.lambda_value * torch.sum(torch.exp(logvar) ** 2))
        return mu + eps * std

    def forward(self, x):
        encoded = self.encoder(x)
        mu, logvar = encoded.chunk(2, dim=-1)
        z = self.reparameterize(mu, logvar)
        reconstructed = self.decoder(z)

        return reconstructed, mu, logvar


class Discriminator(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)


def interpolate_background(background_data, target_shape):
    # 获取背景数据的形状
    original_shape = background_data.shape

    # 计算每个轴的插值比例
    scale = [t / o for t, o in zip(target_shape, original_shape)]

    # 创建插值函数
    interpolator = interpolate.interp2d(
        x=np.arange(original_shape[1]),
        y=np.arange(original_shape[0]),
        z=background_data,
        kind='linear'
    )

    # 生成目标形状的插值结果
    interpolated_background = interpolator(
        np.arange(target_shape[1]) * scale[1],
        np.arange(target_shape[0]) * scale[0]
    )

    return interpolated_background


def psnr(data_input, reconstruct):
    data_input = (data_input - data_input.min()) / (data_input.max() - data_input.min())
    reconstruct = (reconstruct - reconstruct.min()) / (reconstruct.max() - reconstruct.min())

    data_input_cpu = data_input.detach().cpu().numpy()  # 将data_input转移到CPU并转换为numpy数组
    reconstruct_cpu = reconstruct.detach().cpu().numpy()  # 将reconstruct转移到CPU并转换为numpy数组

    target_data = np.array(data_input_cpu)
    ref_data = np.array(reconstruct_cpu)
    diff = ref_data - target_data
    diff = diff.flatten('C')
    rmse = math.sqrt(np.mean(diff ** 2.))

    return 20 * np.log10(1.0 / rmse)


start_time = time.time()
dataset = 'E:/ssrow_code/dataset/abu-airport-4.mat'
img_dataset = open_file(dataset, 'data')
ground_truth = open_file(dataset, 'map')

d_dataset = ts_generation(img_dataset, ground_truth, type=0)
# d_dataset = hyper_normalize(d_dataset)

img_norm = hyper_normalize(img_dataset)
M_2d = hyperConvert2d(img_norm)
img_2d = torch.tensor(M_2d).float()  # torch.Size([204, 10000])
print('img_2d', img_2d.shape)
# ===========================

data_segundo = 'E:/ssrow_code/abu-urban-1/urban_1_data.mat'
target = torch.tensor(open_file(data_segundo, 'target').T).float()  # torch.Size([224, 2176])
background = torch.tensor(open_file(data_segundo, 'background').T).float()  # torch.Size([224, 72824])
# print('back', background.shape)
interpolated_background = torch.tensor(interpolate_background(background, (191, 10000))).float()

input_size = img_2d.shape[1]
batch_size = 256
latent_size = 256
hidden_size = 512
learning_rate = 0.001
keep_prob = 1
epochs = 100

# ===========================
img_dataset_1 = TensorDataset(interpolated_background)
dataloader = DataLoader(img_dataset_1, batch_size=batch_size, shuffle=True)
# ========================
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
vae = VAE(input_size, latent_size, hidden_size, output_size=input_size).to(device)
discriminator = Discriminator(input_size, hidden_size).to(device)

# 定义优化器
vae_optimizer = optim.Adam(vae.parameters(), lr=learning_rate)
dis_optimizer = optim.Adam(discriminator.parameters(), lr=learning_rate)

criterion = nn.BCELoss()
torch.nn.utils.clip_grad_norm_(discriminator.parameters(), max_norm=1)

# ====================`

# vae_scheduler = optim.lr_scheduler.ReduceLROnPlateau(vae_optimizer, mode='min', factor=0.5, patience=5, verbose=True)
# dis_scheduler = optim.lr_scheduler.ReduceLROnPlateau(dis_optimizer, mode='min', factor=0.5, patience=5, verbose=True)

print('训练开始！')
for epoch in range(epochs):
    vae.train()
    total_vae_loss = 0
    total_discriminator_loss = 0
    reconstructed_results = []

    best_psnr = float('-inf')
    best_model_state = None

    for data in dataloader:
        data = data[0].to(device)
        vae_optimizer.zero_grad()

        reconstructed, mu, logvar = vae(data)
        reconstruct_train_psnr = psnr(data, reconstructed)

        discriminator_real = discriminator(data)
        discriminator_fake = discriminator(reconstructed)

        recon_loss = F.mse_loss(reconstructed, data, reduction='sum')
        kl_divergence = -0.5 * torch.sum(1 + logvar - mu.pow(2) - logvar.exp())
        vae_loss = recon_loss + kl_divergence

        # F.binary_cross_entropy
        discriminator_loss = criterion(discriminator_real, torch.ones_like(discriminator_real).to(device)) + \
                              criterion(discriminator_fake, torch.zeros_like(discriminator_fake).to(device))

        total_loss = vae_loss + discriminator_loss
        total_loss.backward()
        vae_optimizer.step()

        total_vae_loss += vae_loss.item()
        total_discriminator_loss += discriminator_loss.item()

        reconstructed_results.append(reconstructed.detach().cpu().numpy())

    # Output average loss for each epoch
    avg_vae_loss = total_vae_loss / len(dataloader.dataset)
    avg_dis_loss = total_discriminator_loss / len(dataloader.dataset)
    print(f'Epoch [{epoch + 1}/{epochs}], VAE Loss: {avg_vae_loss}, '
          f'Discriminator Loss: {avg_dis_loss}, psnr:{reconstruct_train_psnr}')

    if reconstruct_train_psnr > best_psnr:
        best_psnr = reconstruct_train_psnr
        best_model_state = vae.state_dict()

    # Adjust learning rate based on validation loss
    # vae_scheduler.step(avg_vae_loss)
    # dis_scheduler.step(avg_dis_loss)

# reconstructed_results = np.concatenate(reconstructed_results)

print('Training finished.')


vae.eval()
with torch.no_grad():
    reconstructed_results, _, _ = vae(img_2d.to(device))
    reconstructed_results = reconstructed_results.cpu().numpy()

print('recon', reconstructed_results.shape)
# ==================
# savemat('E:/ssrow_code/abu-airport-4/reconstructed_background.mat', {'reconstructed_background': reconstructed_results})
savemat('E:/ssrow_code/abu-airport-4/reconstructed_spatial.mat', {'reconstructed_spatial': reconstructed_results})

# 保存 VAE 模型的权重
# torch.save(generator.state_dict(), './spatial/generator_weights.pth')  # 保存 Generator 模型的权重
# torch.save(discriminator.state_dict(), './spatial/discriminator_weights.pth')  # 保存 Discriminator 模型的权重
print('保存成功！')

# ====================
result_recon = hyperCem(reconstructed_results, d_dataset, reconstructed_results)
out_recon = hyperConvert3d(result_recon, img_norm.shape[0], img_norm.shape[1], 1)


# coarse
# result_coarse = hyperCem(img_2d, d_dataset_norm, img_2d)
# out_coarse = hyperConvert3d(result_coarse, img_dataset.shape[0], img_dataset.shape[1], 1)

plt.figure(1)
plt.subplot(1, 3, 1)
plt.imshow(img_norm[:, :, 29], cmap='gray'), plt.axis('off'), plt.title('orinal_img')

plt.subplot(1, 3, 2)
plt.imshow(out_recon), plt.axis('off'), plt.title('reconstruct spatial')

# plt.subplot(1, 3, 3)
# plt.imshow(out_restored), plt.axis('off'), plt.title('reconstruct spatial')
plt.show()
end_time = time.time()
duration = end_time - start_time
print(f"程序运行时长：{duration}秒")