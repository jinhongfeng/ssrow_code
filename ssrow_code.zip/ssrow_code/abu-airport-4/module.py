import math
import os

import imageio
import numpy as np
import spectral
from scipy.io import loadmat


def open_file(dataset, dataset_key):
    _, ext = os.path.splitext(dataset)
    ext = ext.lower()
    if ext == '.mat':
        key = dataset_key  # 定义您希望获取的键名
        return loadmat(dataset)[key]  # 加载指定键名对应的数据集
    elif ext == '.tif' or ext == '.tiff':
        return imageio.imread(dataset)
    elif ext == '.hdr':
        img = spectral.open_image(dataset)
        return img.load()
    else:
        raise ValueError("Unknown file format: {}".format(ext))


def hyperCorr(M, regularization_lambda=1e-6):
    p, N = M.shape
    R = np.dot(M, M.T) / N
    regularized_matrix = R + regularization_lambda * np.identity(p)
    # regularized_matrix = R
    return regularized_matrix


def hyperConvert2d(M):
    if M.ndim > 3 or M.ndim < 2:
        raise ValueError("Input image must be m x n x p or m x n")

    if M.ndim == 2:
        numBands = 1
        h, w = M.shape
    else:
        h, w, numBands = M.shape

    M = np.reshape(M, (w * h, numBands)).T
    return M


def hyper_normalize(M):
    min_val = M.min()
    max_val = M.max()

    normalized_M = (M - min_val) / (max_val - min_val)
    if max_val == min_val:
        normalized_M = np.zeros(M.shape)
    else:
        normalized_M = normalized_M / (max_val - min_val)
    return normalized_M


def hyperConvert3d(M, h, w, numBands):
    if M.ndim != 2:
        raise ValueError("Input image must be p x N.")

    numBands, N = M.shape

    if N == 1:
        M = np.reshape(M, (h, w))
    else:
        if N != h * w * numBands:
            raise ValueError("Input array size does not match specified dimensions.")
        M = np.reshape(M.T, (h, w, numBands))

    return M


def hyperCem(input_image, target, correlation_matrix):
    # input_image，一个表示输入图像的二维数组，target，一个表示目标的一维数组，和 threshold，一个用于区分目标和背景样本的阈值。

    if input_image.ndim != 2:
        raise ValueError("Input image must be p x N.")

    p, N = input_image.shape

    if not np.array_equal(target.shape, (p, 1)):
        raise ValueError("Input target must be p x 1.")

    R_hat = hyperCorr(correlation_matrix)
    # Equation 6: w = inv(target' * inv(R) * target) * inv(R) * target
    invRtarget = np.dot(np.linalg.inv(R_hat), target)
    weights = np.dot(invRtarget, np.linalg.inv(np.dot(target.T, invRtarget)))
    results = np.dot(weights.T, input_image)

    return results
# def hyperCem(input_image, target, correlation_matrix, target_weight=2, background_penalty=0.5):
#     # input_image，一个表示输入图像的二维数组，target，一个表示目标的一维数组，和 threshold，一个用于区分目标和背景样本的阈值。
#
#     if input_image.ndim != 2:
#         raise ValueError("Input image must be p x N.")
#
#     p, N = input_image.shape
#
#     if not np.array_equal(target.shape, (p, 1)):
#         raise ValueError("Input target must be p x 1.")
#
#     R_hat = hyperCorr(correlation_matrix)
#
#     # 引入惩罚项，使背景端元的反射率降低
#     penalty = background_penalty * np.identity(p)
#     R_hat += penalty
#
#     # 强调目标端元，可以通过调整权重来实现
#     target_weight_matrix = target_weight * np.identity(p)
#     R_hat += target_weight_matrix
#
#     # Equation 6: w = inv(target' * inv(R) * target) * inv(R) * target
#     invRtarget = np.dot(np.linalg.inv(R_hat), target)
#     weights = np.dot(invRtarget, np.linalg.inv(np.dot(target.T, invRtarget)))
#     results = np.dot(weights.T, input_image)
#
#     return results


# ========================
def get_m8(cube, method='local'):
    row_num, col_num, band_num = cube.shape
    if method == 'local':
        m8cube = np.zeros(shape=(row_num, col_num, band_num), dtype=np.double)

        m8cube[1:row_num - 1, 1:col_num - 1] = (cube[1:row_num - 1, 2:col_num] + cube[1:row_num - 1, 0:col_num - 2] +
                                                cube[2:row_num, 1:col_num - 1] + cube[0:row_num - 2, 1:col_num - 1] +
                                                cube[2:row_num, 2:col_num] + cube[2:row_num, 0:col_num - 2] +
                                                cube[0:row_num - 2, 2:col_num] + cube[0:row_num - 2, 0:col_num - 2]) / 8

        m8cube[0, 1:col_num - 1] = np.squeeze((cube[0, 2:col_num] + cube[0, 0:col_num - 2] +
                                               cube[1, 1:col_num - 1] + cube[1, 2:col_num] + cube[1,
                                                                                             0:col_num - 2]) / 5)
        m8cube[row_num - 1, 1:col_num - 1] = np.squeeze(
            (cube[row_num - 1, 2:col_num] + cube[row_num - 1, 0:col_num - 2] +
             cube[row_num - 2, 0:col_num - 2] + cube[row_num - 2,
                                                1:col_num - 1] + cube[
                                                                 row_num - 2,
                                                                 2:col_num]) / 5)

        m8cube[1:row_num - 1, 0] = np.squeeze((cube[0:row_num - 2, 0] + cube[2:row_num, 0] +
                                               cube[0:row_num - 2, 1] + cube[2:row_num, 1] + cube[1:row_num - 1,
                                                                                             1]) / 5)
        m8cube[1:row_num - 1, col_num - 1] = np.squeeze(
            (cube[0:row_num - 2, col_num - 1] + cube[2:row_num, col_num - 1] +
             cube[0:row_num - 2, col_num - 2] + cube[1:row_num - 1,
                                                col_num - 2] + cube[2:row_num,
                                                               col_num - 2]) / 5)

        m8cube[0, 0] = np.squeeze((cube[0, 1] + cube[1, 0] + cube[1, 1]) / 3)
        m8cube[0, col_num - 1] = np.squeeze((cube[0, col_num - 2] + cube[1, col_num - 1] + cube[1, col_num - 2]) / 3)
        m8cube[row_num - 1, 0] = np.squeeze((cube[row_num - 1, 1] + cube[row_num - 2, 0] + cube[row_num - 2, 1]) / 3)
        m8cube[row_num - 1, col_num - 1] = np.squeeze((cube[row_num - 1, col_num - 2] + cube[row_num - 2, col_num - 1] +
                                                       cube[row_num - 2, col_num - 2]) / 3)

    elif method == 'global':
        m8cube = np.mean(cube, (0, 1))

    else:
        raise ValueError('method must be "local" or "global"')

    return m8cube


def get_cov8(cube, m8_cube=None, method='local'):
    if m8_cube is None:
        m8_cube = get_m8(cube, method)
    rows, cols, bands = cube.shape
    x = np.subtract(cube, m8_cube, dtype=np.double)
    x = x.reshape(rows * cols, bands)  # flatten to 2D array
    cov = np.cov(x, rowvar=False, bias=True)  # compute covariance
    return cov


def get_pca(data, mean=None, cov=None):
    row, col, bands = data.shape
    cube = np.zeros(shape=(row, col, bands), dtype=np.double)
    if mean is None:
        mean = get_m8(data)
    if cov is None:
        cov = get_cov8(data, mean)

    eigval, eigvec = np.linalg.eig(cov)
    eigval_real = eigval ** 0.5
    scale_eigvec = np.matmul(np.linalg.pinv(np.diag(np.sqrt(eigval))), eigvec.T, dtype=np.double)
    # scale_eigvec = np.matmul(np.linalg.pinv(np.diag(eigval_real)), eigvec.T)
    upscale_eigvec = np.matmul(np.diag(np.sqrt(eigval)), eigvec.T, dtype=np.double)

    for r in range(row):
        for c in range(col):
            cube[r, c, :] = np.matmul(scale_eigvec, data[r, c, :], dtype=np.double)
    # eigvec 特征向量，eigval特征值
    return cube, eigvec, eigval


# ========================

def choose_train_and_test_point(train_data, test_data, true_data, train_rate):
    pos_train = {}
    number_train = []
    pos_test = {}
    number_test = []
    pos_true = {}
    number_true = []

    # -------------------------for train data------------------------------------
    each_class_train = np.argwhere(train_data == 1)  # Assuming class 1 is the target
    percentage_train = math.ceil(train_rate * each_class_train.shape[0])  # Calculate the percentage and round up
    number_train.append(percentage_train)
    pos_train[1] = each_class_train[:percentage_train].astype(int)

    # --------------------------for test data------------------------------------
    each_class_test = np.argwhere(test_data == 1)  # Assuming class 1 is the target
    number_test.append(each_class_test.shape[0])
    pos_test[1] = each_class_test.astype(int)

    # --------------------------for true data------------------------------------
    each_class_true = np.argwhere(true_data == 1)  # Assuming class 1 is the target
    number_true.append(each_class_true.shape[0])
    pos_true[1] = each_class_true.astype(int)

    return pos_train, pos_test, pos_true, number_train, number_test, number_true


def mirror_hsi(height, width, band, input_normalize, patch):
    padding = patch // 2
    mirror_hsi = np.zeros((height + 2 * padding, width + 2 * padding, band), dtype=float)
    mirror_hsi[padding:(padding + height), padding:(padding + width), :] = input_normalize

    # Left and right padding
    for i in range(padding):
        mirror_hsi[padding:(height + padding), i, :] = input_normalize[:, padding - i - 1, :]
        mirror_hsi[padding:(height + padding), width + padding + i, :] = input_normalize[:, width - 1 - i, :]

    # Top and bottom padding
    for i in range(padding):
        mirror_hsi[i, padding:(width + padding), :] = mirror_hsi[padding * 2 - i - 1, padding:(width + padding), :]
        mirror_hsi[height + padding + i, padding:(width + padding), :] = mirror_hsi[height + padding - 1 - i, padding:(width + padding), :]

    return mirror_hsi


def gain_neighborhood_pixel(mirror_image, point, i, patch=5):
    x = point[i, 0]
    y = point[i, 1]
    temp_image = mirror_image[x:(x + patch), y:(y + patch), :]
    return temp_image


def train_and_test_data(mirror_image, band, train_point, test_point, true_point, patch):
    x_train = np.zeros((train_point.shape[0], patch, patch, band), dtype=float)
    x_test = np.zeros((test_point.shape[0], patch, patch, band), dtype=float)
    x_true = np.zeros((true_point.shape[0], patch, patch, band), dtype=float)
    for i in range(train_point.shape[0]):
        x_train[i, :, :, :] = gain_neighborhood_pixel(mirror_image, train_point, i, patch)
    for j in range(test_point.shape[0]):
        x_test[j, :, :, :] = gain_neighborhood_pixel(mirror_image, test_point, j, patch)
    for k in range(true_point.shape[0]):
        x_true[k, :, :, :] = gain_neighborhood_pixel(mirror_image, true_point, k, patch)
    print("Train data shape = {}, type = {}".format(x_train.shape, x_train.dtype))
    print("Test data shape = {}, type = {}".format(x_test.shape, x_test.dtype))

    return x_train, x_test, x_true


def train_and_test_label(number_train, number_test, number_true):
    y_train = []
    y_test = []
    y_true = []

    # For target class in training data
    for j in range(number_train[0]):  # Assuming class 0 is the target
        y_train.append(1)  # Target class label is 1

    # For background class in training data
    for j in range(number_train[1]):  # Assuming class 1 is the background
        y_train.append(0)  # Background class label is 0

    # For target class in test data
    for j in range(number_test[0]):  # Assuming class 0 is the target
        y_test.append(1)  # Target class label is 1

    # For background class in test data
    for j in range(number_test[1]):  # Assuming class 1 is the background
        y_test.append(0)  # Background class label is 0

    # For target class in true data
    for j in range(number_true[0]):  # Assuming class 0 is the target
        y_true.append(1)  # Target class label is 1

    # For background class in true data
    for j in range(number_true[1]):  # Assuming class 1 is the background
        y_true.append(0)  # Background class label is 0

    y_train = np.array(y_train)
    y_test = np.array(y_test)
    y_true = np.array(y_true)

    return y_train, y_test, y_true