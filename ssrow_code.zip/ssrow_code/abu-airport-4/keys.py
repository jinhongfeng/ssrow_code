from scipy.io import whosmat
# 检查 'HYDICE.mat' 文件中的键
mat_file = "E:/exp/dataset/abu-airport-4.mat"
variables = whosmat(mat_file)

# 输出变量信息
print("变量信息:")
for variable in variables:
    name = variable[0]
    var_type = variable[1]
    var_size = variable[2]
    print(f"键名: {name}, 类型: {var_type}, 大小: {var_size}")


'''HYDICE' 
键名: data, 类型: (80, 100, 162), 大小: uint16
键名: map, 类型: (80, 100), 大小: uint8'''


'''san变量信息:
键名: X, 类型: (189, 40000), 大小: double
键名: d, 类型: (189, 1), 大小: double
键名: groundtruth, 类型: (200, 200), 大小: logical'''

'''变量信息:
键名: Sandiego, 类型: (400, 400, 224), 大小: double'''


