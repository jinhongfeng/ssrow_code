import cv2
import matplotlib.pyplot as plt
import numpy as np
import torch
import torch.nn as nn
from scipy import interpolate

from scipy.ndimage import gaussian_filter
from sklearn import metrics
from sklearn.decomposition import PCA

from sklearn.metrics import auc, roc_curve

from module import open_file, hyper_normalize, hyperConvert2d, hyperCem, hyperConvert3d, hyperCorr
from utils import ts_generation


class VAE(nn.Module):
    def __init__(self, input_size, latent_size, hidden_size):
        super(VAE, self).__init__()
        self.encoder = nn.Sequential(
            nn.Linear(input_size, hidden_size * 2),
            nn.ReLU(),
            nn.Linear(hidden_size * 2, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 2 * latent_size)
        )
        self.decoder = nn.Sequential(
            nn.Linear(latent_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size * 2),
            nn.ReLU(),
            nn.Linear(hidden_size * 2, input_size)
        )

    def reparameterize(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x):
        encoded = self.encoder(x)
        mu, logvar = encoded.chunk(2, dim=-1)
        z = self.reparameterize(mu, logvar)
        reconstructed = self.decoder(z)

        return reconstructed, mu, logvar


class Generator(nn.Module):
    def __init__(self, input_size, hidden_size, output_size):
        super(Generator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, output_size),
            nn.Tanh()
        )

    def forward(self, x):
        return self.model(x)


class Discriminator(nn.Module):
    def __init__(self, input_size, hidden_size):
        super(Discriminator, self).__init__()
        self.model = nn.Sequential(
            nn.Linear(input_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, hidden_size),
            nn.ReLU(),
            nn.Linear(hidden_size, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        return self.model(x)


def calculate_weight(x, alpha):
    # 计算权重q(x)
    return np.where(x >= 0, 1 - np.exp(-alpha * x), 0)


def get_opcs(M_2d, num_band):
    mean = np.mean(M_2d, axis=0)
    centered_img = M_2d - mean
    cov_matrix = np.cov(centered_img)
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvalues = eigenvalues[sorted_indices]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]

    U = sorted_eigenvectors[:, :1]  # (224, 224)

    invs = np.linalg.inv(np.dot(U.T, U))
    P = np.eye(num_band) - np.dot(np.dot(U, invs), U.T)

    S = np.sum(sorted_eigenvectors[:, :num_band], axis=1) / num_band
    return P, U, S


def my_ways(input_img, M_2d, S, beta):
    """高斯滤波后，对其进行双曲正切"""
    smoothed_residual = gaussian_filter(S, sigma=1)
    dete = np.tanh(smoothed_residual * beta).reshape(-1, 1)

    enhance_img = dete * input_img
    enhance_img = (enhance_img + M_2d) / 2
    return enhance_img


def experiment_1():
    weight = calculate_weight(reconstruct_spatial, 1e-3)
    weight_spectral = calculate_weight(original + reconstructed, 1e-3).T
    residual = (M_2d - reconstruct_spatial) * weight
    spectraled = (M_2d - reconstruct_spectral) * weight_spectral

    final = spectraled * residual
    P, U, S = get_opcs(M_2d, img_norm.shape[2])
    enhance_final = my_ways(final, M_2d, S, beta=1)

    final_end = np.dot(P, enhance_final)

    # result_coarse = hyperCem(M_2d, d_dataset, M_2d)
    # out_coarse = hyperConvert3d(result_coarse, img_norm.shape[0], img_norm.shape[1], 1)

    # result_residual = hyperCem(residual, d_dataset, residual)
    # out_residual = hyperConvert3d(result_residual, img_norm.shape[0], img_norm.shape[1], 1)
    # result_spectraled = hyperCem(spectraled, d_dataset, spectraled)
    # out_spectraled = hyperConvert3d(result_spectraled, img_norm.shape[0], img_norm.shape[1], 1)
    # result_final = hyperCem(final, d_dataset, final)
    # out_final = hyperConvert3d(result_final, img_norm.shape[0], img_norm.shape[1], 1)

    # # result_enhance = enhance_contrast(result_coarse)
    result_enhance = hyperCem(enhance_final, target_spectrum, enhance_final)
    out_enhance = hyperConvert3d(result_enhance, img_norm.shape[0], img_norm.shape[1], 1)

    result_final_end = hyperCem(final_end, target_spectrum, final_end)
    out_final_end = hyperConvert3d(result_final_end, img_norm.shape[0], img_norm.shape[1], 1)


# ====================
    plt.figure(1)
    plt.subplot(3, 3, 1)
    plt.imshow(img_norm[:, :, 29]), plt.axis('off'), plt.title('orinal_img')
    plt.subplot(3, 3, 2)
    plt.imshow(ground_truth), plt.axis('off'), plt.title('ground_truth')
    # plt.subplot(3, 3, 3)
    # plt.imshow(np.abs(out_coarse)), plt.axis('off'), plt.title('out_coarse')
    # plt.subplot(3, 3, 4)
    # plt.imshow(np.abs(out_residual)), plt.axis('off'), plt.title('out_residual')
    # plt.subplot(3, 3, 5)
    # plt.imshow(out_spectraled), plt.axis('off'), plt.title('out_spectral')
    # plt.subplot(3, 3, 6)
    # plt.imshow(out_final), plt.axis('off'), plt.title('out_final')
    plt.subplot(3, 3, 7)
    plt.imshow(np.abs(out_enhance)), plt.axis('off'), plt.title('out_enhance')
    plt.subplot(3, 3, 8)
    plt.imshow(np.abs(out_final_end)), plt.axis('off'), plt.title('out_final_end')
    plt.tight_layout()
    plt.show()

    # 计算 ROC 曲线的参数
    # fpr_out, tpr_out, thresholds_out = roc_curve(ground_truth.flatten(), out_coarse.flatten())
    # roc_auc_out = auc(fpr_out, tpr_out)
    #
    # fpr_out_1, tpr_out_1, thresholds_out_1 = roc_curve(ground_truth.flatten(), out_residual.flatten())
    # roc_auc_out_1 = auc(fpr_out_1, tpr_out_1)
    #
    # fpr_out_2, tpr_out_2, thresholds_out_2 = roc_curve(ground_truth.flatten(), out_spectraled.flatten())
    # roc_auc_out_2 = auc(fpr_out_2, tpr_out_2)
    # #
    # fpr_out_3, tpr_out_3, thresholds_out_3 = roc_curve(ground_truth.flatten(), out_final.flatten())
    # roc_auc_out_3 = auc(fpr_out_3, tpr_out_3)
    # # #
    fpr_out_4, tpr_out_4, thresholds_out_4 = roc_curve(ground_truth.flatten(), out_enhance.flatten())
    roc_auc_out_4 = auc(fpr_out_4, tpr_out_4)

    fpr_out_5, tpr_out_5, thresholds_out_5 = roc_curve(ground_truth.flatten(), out_final_end.flatten())
    roc_auc_out_5 = auc(fpr_out_5, tpr_out_5)
    # 绘制 ROC 曲线
    plt.figure(figsize=(8, 6))
    # plt.plot(fpr_out, tpr_out, color='red', lw=2, label='out_coarse (area = %0.7f)' % roc_auc_out)
    # plt.plot(fpr_out_1, tpr_out_1, color='green', lw=2, label='out_residual (area = %0.7f)' % roc_auc_out_1)
    # plt.plot(fpr_out_2, tpr_out_2, color='blue', lw=2, label='out_spectral (area = %0.7f)' % roc_auc_out_2)
    # plt.plot(fpr_out_3, tpr_out_3, color='black', lw=2, label='out_final (area = %0.7f)' % roc_auc_out_3)
    plt.plot(fpr_out_4, tpr_out_4, color='purple', lw=2, label='out_enhance (area = %0.7f)' % roc_auc_out_4)
    plt.plot(fpr_out_5, tpr_out_5, color='gray', lw=2, label='out_final_end (area = %0.7f)' % roc_auc_out_5)
    plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('urban_1 AUC')
    plt.legend(loc="lower right")
    plt.show()


if __name__ == '__main__':
    dataset = 'E:/ssrow_code/dataset/abu-airport-4.mat'
    img_dataset = open_file(dataset, 'data')
    ground_truth = open_file(dataset, 'map')

    d_dataset = ts_generation(img_dataset, ground_truth, type=0)
    target_spectrum = hyper_normalize(d_dataset)

    recon_spatial = 'E:/ssrow_code/abu-airport-4/reconstructed_spatial.mat'
    reconstruct_spatial = open_file(recon_spatial, 'reconstructed_spatial')
    recon_spectral = 'E:/ssrow_code/abu-airport-4/reconstructed_spectral.mat'
    reconstruct_spectral = open_file(recon_spectral, 'reconstructed_spectral').T  # (224, 75000)
    recon_background = 'E:/ssrow_code/abu-airport-4/reconstructed_background.mat'
    reconstruct_background = open_file(recon_background, 'reconstructed_background')

    vae_dis = 'E:/ssrow_code/abu-airport-4/spectral_VAE_DIS.mat'
    original = open_file(vae_dis, 'original_results')
    reconstructed = open_file(vae_dis, 'reconstructed_results')

    img_norm = hyper_normalize(img_dataset)
    M_2d = hyperConvert2d(img_norm)
    experiment_1()
