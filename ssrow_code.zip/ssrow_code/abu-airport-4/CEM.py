import cv2
import matplotlib.pyplot as plt
import numpy as np
from sklearn.decomposition import PCA
from sklearn.metrics import auc, roc_curve

from module import open_file
from utils import ts_generation

def hyperCorr(M, regularization_lambda=1e-6):
    p, N = M.shape
    R = np.dot(M, M.T) / N

    # regularized_matrix = R + regularization_lambda * np.identity(p)
    regularized_matrix = R
    return regularized_matrix


def hyperCem(input_image, target, correlation_matrix):
    # input_image，一个表示输入图像的二维数组，target，一个表示目标的一维数组，和 threshold，一个用于区分目标和背景样本的阈值。

    if input_image.ndim != 2:
        raise ValueError("Input image must be p x N.")

    p, N = input_image.shape

    if not np.array_equal(target.shape, (p, 1)):
        raise ValueError("Input target must be p x 1.")

    R_hat = hyperCorr(correlation_matrix)
    # Equation 6: w = inv(target' * inv(R) * target) * inv(R) * target
    invRtarget = np.dot(np.linalg.inv(R_hat), target)
    weights = np.dot(invRtarget, np.linalg.inv(np.dot(target.T, invRtarget)))
    results = np.dot(weights.T, input_image)

    return results


def hyperConvert3d(M, h, w, numBands):
    if M.ndim != 2:
        raise ValueError("Input image must be p x N.")

    numBands, N = M.shape

    if N == 1:
        M = np.reshape(M, (h, w))
    else:
        if N != h * w * numBands:
            raise ValueError("Input array size does not match specified dimensions.")
        M = np.reshape(M.T, (h, w, numBands))

    return M


def hyperConvert2d(M):
    if M.ndim > 3 or M.ndim < 2:
        raise ValueError("Input image must be m x n x p or m x n")

    if M.ndim == 2:
        numBands = 1
        h, w = M.shape
    else:
        h, w, numBands = M.shape

    M = np.reshape(M, (w * h, numBands)).T
    return M


def hyper_normalize(M):
    min_val = M.min()
    max_val = M.max()

    normalized_M = (M - min_val) / (max_val - min_val)
    if max_val == min_val:
        normalized_M = np.zeros(M.shape)
    # else:
    #     normalized_M = normalized_M / (max_val - min_val)
    return normalized_M


def enhance_contrast(image):
    # 将 PyTorch 张量转换为 NumPy 数组
    # img_numpy = image.numpy()

    # 将图像从 [0, 1] 转换为 [0, 255] 范围
    img_numpy = (image * 255).astype(np.uint8)
    # img_numpy = img_numpy.astype(np.uint8)
    # 对图像进行直方图均衡化
    img_enhanced = cv2.equalizeHist(img_numpy)

    # 将增强后的图像转换回 PyTorch 张量
    # enhanced_tensor = torch.tensor(img_enhanced, dtype=torch.float32) / 255.0
    enhanced = img_enhanced / 255.0
    return enhanced


def apply_pca(image_data, n_components):
    # 将图像数据转换为二维数组，每一行表示一个样本
    num_samples = image_data.shape[0] * image_data.shape[1]
    flattened_data = image_data.reshape(num_samples, -1)

    # 创建PCA对象并拟合数据
    pca = PCA(n_components=n_components)
    pca.fit(flattened_data)

    # 将数据投影到新的低维空间
    reduced_data = pca.transform(flattened_data)

    # 将降维后的数据转换回原始形状
    reconstructed_data = pca.inverse_transform(reduced_data)
    reconstructed_data = reconstructed_data.reshape(image_data.shape)

    return reduced_data, reconstructed_data


dataset = 'E:/ssrow_code/dataset/abu-airport-4.mat'
img_dataset = open_file(dataset, 'data')  # (250,300,224)
ground_truth = open_file(dataset, 'map')  # (250, 300)

num_target_pixels = len(np.where(ground_truth == 1)[0])
print("真实地址中共有 {} 个目标像素。".format(num_target_pixels))
# d_dataset = get_target_information(img_dataset, ground_truth)
d_dataset = ts_generation(img_dataset, ground_truth, type=0)

# d_dataset = open_file(dataset, 'd')  # (224,1)
# d_dataset = img_dataset[54, 29, :].reshape(-1, 1)

# d_dataset_norm = hyper_normalize(d_dataset)
img_norm = hyper_normalize(img_dataset)
M_2d = hyperConvert2d(img_norm)

# n_components = img_dataset.shape[2]
# reduced_data, reconstructed_img = apply_pca(img_norm, n_components)
# M_2d = reduced_data.T

# CEM
result_coarse = hyperCem(M_2d, d_dataset, M_2d)
out_coarse = hyperConvert3d(result_coarse, img_dataset.shape[0], img_dataset.shape[1], 1)
# result_coarse_hance = hyperCem(coarse_enhance, d_dataset_norm, coarse_enhance)
# out_coarse_hance = hyperConvert3d(coarse_enhance, img_dataset.shape[0], img_dataset.shape[1], 1)
plt.figure(1)
plt.subplot(2, 2, 1)
plt.imshow(img_norm[:, :, 29]), plt.axis('off'), plt.title('orinal_img')
plt.subplot(2, 2, 2)
plt.imshow(ground_truth), plt.axis('off'), plt.title('ground_truth')
plt.subplot(2, 2, 3)
plt.imshow(out_coarse), plt.axis('off'), plt.title('out_coarse')
# plt.subplot(2, 2, 4)
# plt.imshow(out_coarse_hance), plt.axis('off'), plt.title('out_enhance')
plt.show()

fpr_out, tpr_out, thresholds_out = roc_curve(ground_truth.flatten(), out_coarse.flatten())
roc_auc_out = auc(fpr_out, tpr_out)
plt.figure(figsize=(8, 6))
plt.plot(fpr_out, tpr_out, color='red', lw=2, label='out_coarse (area = %0.7f)' % roc_auc_out)
plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('airport_4 AUC')
plt.legend(loc="lower right")
plt.show()