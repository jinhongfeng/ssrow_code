import numpy as np
from matplotlib import pyplot as plt




# beta_values = [1, 3, 5, 7, 9]
# SDdata = [0.998334365532659, 0.9987013697373274, 0.9986960764074524, 0.998561978717285, 0.9982920188936587]
# aviris = [0.9968064602993546, 0.9920002662543759, 0.9854944313502425, 0.9781724360157453, 0.9701106771030314]
# airport_4 = [0.998065057008719, 0.9966918175720993, 0.9939470154258887, 0.9903822937625755, 0.9864386317907444]
# segundo = [0.9963755063260775, 0.9908565132617169, 0.9682471342993509, 0.929246847456204, 0.8974977098597364]
# urban_1 = [0.9993433617175373, 0.9993178174365263, 0.9990112860643926, 0.9977130355471209, 0.9955537924992974]
# urban_2 = [0.9991913366863808, 0.9991900260489195, 0.9991900260489195, 0.9991906813676501, 0.9991906813676501]
# HYDICE = []
#
# colors = ['b', 'g', 'r', 'c', 'm', 'y']
# datasets = ['Segundo', 'Sandiego1', 'Sandiego2', 'abu-airport-4', 'abu-urban-1', 'abu-urban-2']
# plt.figure()
#
# plt.plot(beta_values, segundo, color=colors[0], label=datasets[0], marker='o')
# plt.plot(beta_values, SDdata, color=colors[1], label=datasets[1], marker='o')
# plt.plot(beta_values, aviris, color=colors[2], label=datasets[2], marker='o')
# plt.plot(beta_values, airport_4, color=colors[3], label=datasets[3], marker='o')
# plt.plot(beta_values, urban_1, color=colors[4], label=datasets[4], marker='o')
# plt.plot(beta_values, urban_2, color=colors[5], label=datasets[5], marker='o')
#
# plt.xlabel('Beta value')
# plt.xlim(0, beta_values[-1]+1)
# plt.ylabel('Normalized AUC value')
# # plt.title('AUC value vs. Beta value for different datasets')
# plt.gca().yaxis.set_major_formatter('{:.4f}'.format)  # 设置纵坐标显示四位小数
#
# # 添加每条曲线的数据集标签
# plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), ncol=3)
#
# plt.subplots_adjust(bottom=0.2)  # 调整底部空白区域以便显示数据集标签
#
# for i, dataset in enumerate(datasets):
#     plt.text(1, 0.05-0.03*i, f'{colors[i]}: {dataset}', transform=plt.gcf().transFigure)
#
# plt.show()

# ===================================
# lambda 正则化参数
Segundo = [0.5167010, 0.9983757, 0.9969429, 0.9916476, 0.9931446]
Sandiego = [0.4177125, 0.9985196, 0.9976445, 0.9970604, 0.4508805]
airport_4 = [0.5309465, 0.9993662, 0.9981992, 0.9847653, 0.5075570]
abu_urban_1 = [0.4825608, 0.9995627, 0.9992848, 0.9928822, 0.9847020]
abu_urban_2 = [0.5626003, 0.9995079, 0.9991940, 0.9988724, 0.9993270]
HYDICE = [0.6392946, 0.9999209, 0.9998154, 0.9942165, 0.9684976]

alpha = [0, 1.0e-9, 1.0e-6, 1.0e-3, 1.0e-0]
colors = ['#f9403f', '#6afd64', '#6098F9', '#ffa03e', '#000000', '#B756D7']
# datasets = ['Segundo', 'Sandiego', 'abu-airport-4', 'abu-urban-1', 'abu-urban-2', 'HYDICE']

# alpha = [0, 1.0e-9, 1.0e-6, 1.0e-3, 1.0e-0]
datasets = ['Segundo', 'Sandiego', 'airport_4', 'abu_urban_1', 'abu_urban_2', 'HYDICE']
data = {
    'Segundo': [0.5167010, 0.9983757, 0.9969429, 0.9916476, 0.9931446],
    'Sandiego': [0.4177125, 0.9985196, 0.9976445, 0.9970604, 0.4508805],
    'airport_4': [0.5309465, 0.9993662, 0.9981992, 0.9847653, 0.5075570],
    'abu_urban_1': [0.4825608, 0.9995627, 0.9992848, 0.9928822, 0.9847020],
    'abu_urban_2': [0.5626003, 0.9995079, 0.9991940, 0.9988724, 0.9993270],
    'HYDICE': [0.6392946, 0.9999209, 0.9998154, 0.9942165, 0.9684976]
}

# 设置画布和图形大小
plt.figure(figsize=(10, 6))

# 绘制每个数据集的折线
for dataset, color in zip(datasets, colors):
    plt.plot(alpha, data[dataset], marker='o', linestyle='-', color=color, linewidth=2, markersize=8, label=dataset)

# 设置标题和标签
plt.title('Dataset Performance across Different Alpha Values')
plt.xlabel('Alpha')
plt.ylabel('Performance')
plt.xscale('log')  # 使用对数刻度显示alpha值

# 添加图例
plt.legend(loc='lower right')

# 设置y轴范围
plt.ylim(0, 1)

# 显示网格
plt.grid(True, linestyle='--', alpha=0.7)

# 显示图形
plt.tight_layout()
plt.show()

# plt.figure()
#
# plt.plot(alpha, Segundo, color=colors[0], label=datasets[0], marker='o')
# plt.plot(alpha, Sandiego, color=colors[1], label=datasets[1], marker='o')
# plt.plot(alpha, airport_4, color=colors[2], label=datasets[2], marker='o')
# plt.plot(alpha, abu_urban_1, color=colors[3], label=datasets[3], marker='o')
# plt.plot(alpha, abu_urban_2, color=colors[4], label=datasets[4], marker='o')
# plt.plot(alpha, HYDICE, color=colors[5], label=datasets[5], marker='o')
#
# # plt.xlabel('Beta value')
# plt.xlim(0, alpha[-1]+1)
# # plt.ylabel('Normalized AUC value')
# plt.title('λ')
# plt.gca().yaxis.set_major_formatter('{:.4f}'.format)  # 设置纵坐标显示四位小数
#
# # 添加每条曲线的数据集标签
# plt.legend(loc='lower center', bbox_to_anchor=(0.5, -0.3), ncol=3)
#
# plt.subplots_adjust(bottom=0.2)  # 调整底部空白区域以便显示数据集标签
#
# for i, dataset in enumerate(datasets):
#     plt.text(1, 0.05-0.03*i, f'{colors[i]}: {dataset}', transform=plt.gcf().transFigure)
#
# plt.show()
