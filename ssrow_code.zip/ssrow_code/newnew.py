import os

import imageio
import numpy as np
from matplotlib import pyplot as plt
from scipy.io import loadmat
from scipy.ndimage import gaussian_filter
from sklearn.metrics import auc, roc_curve
from spectral import spectral


from segundo.module import hyper_normalize, hyperConvert2d, hyperConvert3d, hyperCem


def calculate_weight(x, alpha):
    # 计算权重q(x)
    return np.where(x >= 0, 1 - np.exp(-alpha * x), 0)


def get_opcs(M_2d, num_band):
    mean = np.mean(M_2d, axis=0)
    centered_img = M_2d - mean
    cov_matrix = np.cov(centered_img)
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvalues = eigenvalues[sorted_indices]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]

    U = sorted_eigenvectors[:, :1]  # (224, 224)

    S = np.sum(sorted_eigenvectors[:, :num_band], axis=1) / num_band
    print('S', S.shape)
    invs = np.linalg.inv(np.dot(U.T, U))
    P = np.eye(num_band) - np.dot(np.dot(U, invs), U.T)
    return P, U, S


def open_file(dataset, dataset_key):
    _, ext = os.path.splitext(dataset)
    ext = ext.lower()
    if ext == '.mat':
        key = dataset_key  # 定义您希望获取的键名
        return loadmat(dataset)[key]  # 加载指定键名对应的数据集
    elif ext == '.tif' or ext == '.tiff':
        return imageio.imread(dataset)
    elif ext == '.hdr':
        img = spectral.open_image(dataset)
        return img.load()
    else:
        raise ValueError("Unknown file format: {}".format(ext))


def get_target_information(img_dataset, ground_truth):
    target_class_label = 1  # 假设目标类别的标签为1

    # 找到目标像元的位置
    target_pixels = np.where(ground_truth == target_class_label)

    # 提取目标像元的光谱信息
    target_spectra = []
    for i in range(len(target_pixels[0])):
        x = target_pixels[0][i]
        y = target_pixels[1][i]
        target_spectra.append(img_dataset[x, y, :])

    # 将列表转换为 NumPy 数组
    target_spectra = np.array(target_spectra)

    # 计算目标像元的平均光谱
    d_dataset = np.mean(target_spectra, axis=0).reshape(-1, 1)
    return d_dataset


# 输入数据
dataset = 'E:/exp/dataset/SDdata.mat'
img_dataset = open_file(dataset, 'data')  # (100, 100, 189)
ground_truth = open_file(dataset, 'mask')  # (100, 100)
d_dataset = get_target_information(img_dataset, ground_truth)

# 预处理

img_norm = hyper_normalize(img_dataset)
# h, w, p = 200, 200, 189
# if img_dataset.ndim == 2:
#     img_norm = np.transpose(img_norm, (1, 0))  # 40000,189
#     image_shape = (h, w, p)
#     img_norm = np.reshape(img_norm, image_shape, order='F')
#     # img_norm_flip = np.flip(img_norm, axis=1)
#     print('img', img_norm.shape)

M_2d = hyperConvert2d(img_norm)


def exp():
    P, U, S = get_opcs(M_2d, img_norm.shape[2])
    smoothed_S = gaussian_filter(S, sigma=1)
    print('Smoothed', smoothed_S.shape)
    beta = 2
    deta = np.tanh(smoothed_S * beta).reshape(-1, 1)
    enhance_img = deta * M_2d
    # enhance_img = (enhance_img + M_2d) / 2

    P_img = np.dot(P, enhance_img)

    result_enhance = hyperCem(enhance_img, d_dataset, enhance_img)
    out_enhance = hyperConvert3d(result_enhance, img_norm.shape[0], img_norm.shape[1], 1)

    # result_residual = hyperCem(residual, d_dataset, residual)
    # out_residual = hyperConvert3d(result_residual, img_norm.shape[0], img_norm.shape[1], 1)

    result_P = hyperCem(P_img, d_dataset, P_img)
    out_P = hyperConvert3d(result_P, img_norm.shape[0], img_norm.shape[1], 1)

    plt.subplot(2, 2, 1)
    plt.imshow(img_norm[:, :, 29]), plt.axis('off'), plt.title('orinal_img')
    # plt.subplot(2, 2, 2)
    # plt.imshow(np.abs(out_residual)), plt.axis('off'), plt.title('enhance')
    plt.subplot(2, 2, 3)
    plt.imshow((out_enhance)), plt.axis('off'), plt.title('P')
    plt.subplot(2, 2, 4)
    plt.imshow((out_P)), plt.axis('off'), plt.title('P')
    plt.show()


    # fpr_out_1, tpr_out_1, thresholds_out_1 = roc_curve(ground_truth.flatten(), out_residual.flatten())
    # roc_auc_out_1 = auc(fpr_out_1, tpr_out_1)

    fpr_out_2, tpr_out_2, thresholds_out_2 = roc_curve(ground_truth.flatten(), out_enhance.flatten())
    roc_auc_out_2 = auc(fpr_out_2, tpr_out_2)

    fpr_out_4, tpr_out_4, thresholds_out_4 = roc_curve(ground_truth.flatten(), out_P.flatten())
    roc_auc_out_4 = auc(fpr_out_4, tpr_out_4)

    # 绘制 ROC 曲线
    plt.figure(figsize=(8, 6))
    # plt.plot(fpr_out_1, tpr_out_1, color='green', lw=2, label='out_residual (area = %0.7f)' % roc_auc_out_1)
    plt.plot(fpr_out_2, tpr_out_2, color='blue', lw=2, label='out_spectral (area = %0.7f)' % roc_auc_out_2)
    plt.plot(fpr_out_4, tpr_out_4, color='purple', lw=2, label='out_fina (area = %0.7f)' % roc_auc_out_4)
    plt.plot([0, 1], [0, 1], color='gray', lw=2, linestyle='--')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title('Segundo AUC')
    plt.legend(loc="lower right")
    plt.show()
exp()
# 伪彩图
# image_data = img_dataset
# band_r = image_data[:,:,20] / np.max(image_data[:,:,20])  # 红色通道
# band_g = image_data[:,:,10] / np.max(image_data[:,:,10])  # 绿色通道
# band_b = image_data[:,:,5] / np.max(image_data[:,:,5])    # 蓝色通道
#
# # 创建伪彩图
# rgb_image = np.stack([band_r, band_g, band_b], axis=2)
#
# # 显示伪彩图
# plt.imshow(rgb_image)
# plt.title('Pseudo-colored Image')
# plt.axis('off')
# plt.show()