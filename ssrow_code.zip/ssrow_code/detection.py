import os

import imageio
import numpy as np
import spectral
from matplotlib import pyplot as plt
from matplotlib.font_manager import FontProperties
from scipy.io import loadmat
from scipy.ndimage import gaussian_filter
from sklearn.metrics import roc_curve, auc

from utils import ts_generation


def open_file(dataset, dataset_key):
    _, ext = os.path.splitext(dataset)
    ext = ext.lower()
    if ext == '.mat':
        key = dataset_key  # 定义您希望获取的键名
        return loadmat(dataset)[key]  # 加载指定键名对应的数据集
    elif ext == '.tif' or ext == '.tiff':
        return imageio.imread(dataset)
    elif ext == '.hdr':
        img = spectral.open_image(dataset)
        return img.load()
    else:
        raise ValueError("Unknown file format: {}".format(ext))


def calculate_weight(x, alpha):
    # 计算权重q(x)
    return np.where(x >= 0, 1 - np.exp(-alpha * x), 0)


def getkey(dataset, load_mat):
    if dataset == 'SDdata':
        data_key = 'data'
        gt_key = 'mask'
    elif dataset == 'AVIRIS-II':
        data_key = 'data'
        gt_key = 'gt'
    else:
        data_key = 'data'
        gt_key = 'map'

    return load_mat[f'{data_key}'], load_mat[f'{gt_key}']


def standard(X):
    max_value = np.max(X)
    min_value = np.min(X)
    if max_value == min_value:
        return X
    return (X - min_value) / (max_value - min_value)


def hyperConvert2d(M):
    if M.ndim > 3 or M.ndim < 2:
        raise ValueError("Input image must be m x n x p or m x n")

    if M.ndim == 2:
        numBands = 1
        h, w = M.shape
    else:
        h, w, numBands = M.shape

    M = np.reshape(M, (w * h, numBands)).T
    return M


def hyperConvert3d(M, h, w, numBands):
    if M.ndim != 2:
        raise ValueError("Input image must be p x N.")

    numBands, N = M.shape

    if N == 1:
        M = np.reshape(M, (h, w))
    else:
        if N != h * w * numBands:
            raise ValueError("Input array size does not match specified dimensions.")
        M = np.reshape(M.T, (h, w, numBands))

    return M


def hyperCem(input_image, target, correlation_matrix):
    # input_image，一个表示输入图像的二维数组，target，一个表示目标的一维数组，和 threshold，一个用于区分目标和背景样本的阈值。

    if input_image.ndim != 2:
        raise ValueError("Input image must be p x N.")

    p, N = input_image.shape

    if not np.array_equal(target.shape, (p, 1)):
        raise ValueError("Input target must be p x 1.")

    R_hat = hyperCorr(correlation_matrix)
    # Equation 6: w = inv(target' * inv(R) * target) * inv(R) * target
    invRtarget = np.dot(np.linalg.inv(R_hat), target)
    weights = np.dot(invRtarget, np.linalg.inv(np.dot(target.T, invRtarget)))
    results = np.dot(weights.T, input_image)

    return results


def hyperCorr(M, regularization_lambda=1e-6):
    p, N = M.shape
    R = np.dot(M, M.T) / N
    regularized_matrix = R + regularization_lambda * np.identity(p)
    # regularized_matrix = R
    return regularized_matrix


def get_opcs(M_2d, num_band):
    mean = np.mean(M_2d, axis=0)
    centered_img = M_2d - mean
    cov_matrix = np.cov(centered_img)
    eigenvalues, eigenvectors = np.linalg.eigh(cov_matrix)
    sorted_indices = np.argsort(eigenvalues)[::-1]
    sorted_eigenvalues = eigenvalues[sorted_indices]
    sorted_eigenvectors = eigenvectors[:, sorted_indices]

    U = sorted_eigenvectors[:, :1]  # (224, 224)

    invs = np.linalg.inv(np.dot(U.T, U))
    P = np.eye(num_band) - np.dot(np.dot(U, invs), U.T)

    S = np.sum(sorted_eigenvectors[:, :num_band], axis=1) / num_band
    return P, U, S


def my_ways(input_img, M_2d, S, beta):
    """高斯滤波后，对其进行双曲正切"""
    smoothed_residual = gaussian_filter(S, sigma=1)
    dete = np.tanh(smoothed_residual * beta).reshape(-1, 1)

    enhance_img = dete * input_img
    enhance_img = (enhance_img + M_2d) / 2
    return enhance_img


def main(data, target_spectrum, labels):

    target_spectrum = standard(target_spectrum)
    recon_spatial = f'E:/ssrow_code/{dataset}/reconstructed_spatial.mat'
    reconstruct_spatial = open_file(recon_spatial, 'reconstructed_spatial')
    recon_spectral = f'E:/ssrow_code/{dataset}/reconstructed_spectral.mat'
    reconstruct_spectral = open_file(recon_spectral, 'reconstructed_spectral').T  # (224, 75000)

    recon_background = f'E:/ssrow_code/{dataset}/reconstructed_background.mat'
    reconstruct_background = open_file(recon_background, 'reconstructed_background').T

    vae_dis = f'E:/ssrow_code/{dataset}/spectral_VAE_DIS.mat'
    original = open_file(vae_dis, 'original_results')
    reconstructed = open_file(vae_dis, 'reconstructed_results')

    img_norm = standard(data)
    M_2d = hyperConvert2d(img_norm)

    weight = calculate_weight(reconstruct_spatial, 1e-3)
    weight_spectral = calculate_weight(original + reconstructed, 1e-3).T
    residual = (M_2d - reconstruct_spatial) * weight
    spectraled = (M_2d - reconstruct_spectral) * weight_spectral

    final = spectraled * residual
    P, U, S = get_opcs(M_2d, img_norm.shape[2])
    enhance_final = my_ways(final, M_2d, S, beta=1)

    final_end = np.dot(P, enhance_final)

    result_final_end = hyperCem(final_end, target_spectrum, final_end)
    out_final_end = hyperConvert3d(result_final_end, img_norm.shape[0], img_norm.shape[1], 1)

    fpr_out, tpr_out, thresholds_out = roc_curve(labels.flatten(), out_final_end.flatten())
    roc_auc_out = auc(fpr_out, tpr_out)

    return out_final_end, fpr_out, tpr_out, roc_auc_out


if __name__ == "__main__":
    dataset = 'abu-airport-4'
    dir_way = 'E:/double_window/dataset/'
    dir_path = dir_way + f'{dataset}' + '.mat'
    mat = loadmat(dir_path)
    data, labels = getkey(dataset, mat)
    target_spectrum = ts_generation(data, labels, type=0)
    print('1')
    out_final_end, fpr_out, tpr_out, roc_auc_out = main(data, target_spectrum, labels)
    print('2')
    # =========================================
    plt.figure(1)
    plt.subplot(2, 3, 6)
    plt.imshow(np.abs(out_final_end)), plt.axis('off'), plt.title(f'{dataset}_SSROW')
    plt.tight_layout()
    plt.show()

    font_prop = FontProperties()
    font_prop.set_family('Times New Roman')
    plt.figure(num='ROC curve', figsize=[7, 5])
    plt.plot(fpr_out, tpr_out, color='#f9403f', lw=2, label='CEM (area = %0.7f)' % roc_auc_out)

    plt.xscale('log')
    plt.xlim([1e-4, 1.0])  # 范围为[1e-5, 1.0]
    plt.ylim([0.0, 1.0])
    plt.xlabel('False positive rate', fontproperties=font_prop, fontsize=14)  # 虚警率标签字体变大为14
    plt.ylabel('True positive rate', fontproperties=font_prop, fontsize=14)  # 检测率标签字体变大为14
    plt.title(f'{dataset}')
    plt.legend(loc='lower right', facecolor='none', edgecolor='none')
    plt.show()

